<template>
  <section class="trusted-section">
    <div class="auto-container">
      <div class="outer-container">
        <div class="row clearfix">
          <div class="left-col col-xl-5 col-lg-6 col-md-12 col-sm-12">
            <div class="inner">
              <div class="col-header">
                <div class="header-inner">
                  <span>We’re Committed To Deliver High Quality Projects .</span>
                </div>
              </div>
              <div class="features">
                <div class="feature">
                  <div class="count"><span>01</span></div>
                  <h5>TOTAL DESIGN FREEDOM FOR EVERYONE</h5>
                  <div class="sub-text">core features</div>
                </div>
                <div class="feature">
                  <div class="count"><span>02</span></div>
                  <h5>BASIC RULES OF RUNNING WEB AGENCY</h5>
                  <div class="sub-text">core features</div>
                </div>
              </div>
            </div>
          </div>
          <div class="right-col col-xl-7 col-lg-6 col-md-12 col-sm-12">
            <div class="inner">
              <div class="sec-title">
                <h2>We’re trusted by more <br>than 6260 clients<span class="dot">.</span></h2>
                <div class="lower-text">There are many variations of passages of Lorem Ipsum
                  available, but the majority have suffered alteration in some form, simply free
                  text by injected humour, or randomised.</div>
              </div>
              <div class="featured-block-two clearfix">
                <div class="image"><img src="/images/resource/featured-image-5.jpg" alt=""></div>
                <div class="text">
                  <ul>
                    <li> Suspe ndisse sagittis leo.</li>
                    <li>Entum estibulum is posuere.</li>
                    <li>If you are going to use passage.</li>
                    <li>Lorem Ipsum on the tend to repeat.</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  </section>
</template>

<script>
    export default {
        name: "TrustedSection"
    }
</script>

<style scoped>

</style>
