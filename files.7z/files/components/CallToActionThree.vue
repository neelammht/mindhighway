<template>
  <section class="call-to-section-two alternate">
    <div class="auto-container">
      <div class="inner clearfix">
        <h2>We’re Ready to Bring Bigger <br>& Stronger Projects</h2>
        <div class="link-box">
          <a class="theme-btn btn-style-two" href="about.html">
            <i class="btn-curve"></i>
            <span class="btn-title">Contact with us</span>
          </a>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
    export default {
        name: "CallToActionThree"
    }
</script>

<style scoped>

</style>
