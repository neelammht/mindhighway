<template>
  <section class="team-section no-padd-top">
    <div class="auto-container">
      <div class="sec-title centered">
        <h2>Meet the expert team<span class="dot">.</span></h2>
      </div>
    </div>
    <div class="carousel-box">
      <div class="team-carousel">
        <no-ssr>
        <carousel :items="4" :autoplay="true" :margin="30" :responsive="{0: {items: 1},640: {items: 2},992: {items: 3},1200: {items: 4},1500: {items: 4},1600: {items: 5}}">
        <!--Team-->
        <div class="team-block">
          <div class="inner-box">
            <div class="image-box">
              <a href="/about"><img src="/images/resource/team-1.jpg" alt=""></a>
              <ul class="social-links clearfix">
                <li><a href="#"><span class="fab fa-facebook-square"></span></a></li>
                <li><a href="#"><span class="fab fa-twitter"></span></a></li>
                <li><a href="#"><span class="fab fa-instagram"></span></a></li>
                <li><a href="#"><span class="fab fa-pinterest-p"></span></a></li>
              </ul>
            </div>
            <div class="lower-box">
              <h5><a href="#">Kevin martin</a></h5>
              <div class="designation">Designer</div>
            </div>
          </div>
        </div>

        <!--Team-->
        <div class="team-block">
          <div class="inner-box">
            <div class="image-box">
              <a href="/about"><img src="/images/resource/team-2.jpg" alt=""></a>
              <ul class="social-links clearfix">
                <li><a href="#"><span class="fab fa-facebook-square"></span></a></li>
                <li><a href="#"><span class="fab fa-twitter"></span></a></li>
                <li><a href="#"><span class="fab fa-instagram"></span></a></li>
                <li><a href="#"><span class="fab fa-pinterest-p"></span></a></li>
              </ul>
            </div>
            <div class="lower-box">
              <h5><a href="#">Jessica Brown</a></h5>
              <div class="designation">Designer</div>
            </div>
          </div>
        </div>

        <!--Team-->
        <div class="team-block">
          <div class="inner-box">
            <div class="image-box">
              <a href="/about"><img src="/images/resource/team-3.jpg" alt=""></a>
              <ul class="social-links clearfix">
                <li><a href="#"><span class="fab fa-facebook-square"></span></a></li>
                <li><a href="#"><span class="fab fa-twitter"></span></a></li>
                <li><a href="#"><span class="fab fa-instagram"></span></a></li>
                <li><a href="#"><span class="fab fa-pinterest-p"></span></a></li>
              </ul>
            </div>
            <div class="lower-box">
              <h5><a href="#">John Albert</a></h5>
              <div class="designation">Designer</div>
            </div>
          </div>
        </div>

        <!--Team-->
        <div class="team-block">
          <div class="inner-box">
            <div class="image-box">
              <a href="/about"><img src="/images/resource/team-4.jpg" alt=""></a>
              <ul class="social-links clearfix">
                <li><a href="#"><span class="fab fa-facebook-square"></span></a></li>
                <li><a href="#"><span class="fab fa-twitter"></span></a></li>
                <li><a href="#"><span class="fab fa-instagram"></span></a></li>
                <li><a href="#"><span class="fab fa-pinterest-p"></span></a></li>
              </ul>
            </div>
            <div class="lower-box">
              <h5><a href="#">Rose ford</a></h5>
              <div class="designation">Designer</div>
            </div>
          </div>
        </div>

        <!--Team-->
        <div class="team-block">
          <div class="inner-box">
            <div class="image-box">
              <a href="/about"><img src="/images/resource/team-5.jpg" alt=""></a>
              <ul class="social-links clearfix">
                <li><a href="#"><span class="fab fa-facebook-square"></span></a></li>
                <li><a href="#"><span class="fab fa-twitter"></span></a></li>
                <li><a href="#"><span class="fab fa-instagram"></span></a></li>
                <li><a href="#"><span class="fab fa-pinterest-p"></span></a></li>
              </ul>
            </div>
            <div class="lower-box">
              <h5><a href="#">Mike Hardson</a></h5>
              <div class="designation">Designer</div>
            </div>
          </div>
        </div>
        <!--Team-->
        <div class="team-block">
          <div class="inner-box">
            <div class="image-box">
              <a href="/about"><img src="/images/resource/team-1.jpg" alt=""></a>
              <ul class="social-links clearfix">
                <li><a href="#"><span class="fab fa-facebook-square"></span></a></li>
                <li><a href="#"><span class="fab fa-twitter"></span></a></li>
                <li><a href="#"><span class="fab fa-instagram"></span></a></li>
                <li><a href="#"><span class="fab fa-pinterest-p"></span></a></li>
              </ul>
            </div>
            <div class="lower-box">
              <h5><a href="#">Kevin martin</a></h5>
              <div class="designation">Designer</div>
            </div>
          </div>
        </div>

        <!--Team-->
        <div class="team-block">
          <div class="inner-box">
            <div class="image-box">
              <a href="/about"><img src="/images/resource/team-2.jpg" alt=""></a>
              <ul class="social-links clearfix">
                <li><a href="#"><span class="fab fa-facebook-square"></span></a></li>
                <li><a href="#"><span class="fab fa-twitter"></span></a></li>
                <li><a href="#"><span class="fab fa-instagram"></span></a></li>
                <li><a href="#"><span class="fab fa-pinterest-p"></span></a></li>
              </ul>
            </div>
            <div class="lower-box">
              <h5><a href="#">Jessica Brown</a></h5>
              <div class="designation">Designer</div>
            </div>
          </div>
        </div>

        <!--Team-->
        <div class="team-block">
          <div class="inner-box">
            <div class="image-box">
              <a href="/about"><img src="/images/resource/team-3.jpg" alt=""></a>
              <ul class="social-links clearfix">
                <li><a href="#"><span class="fab fa-facebook-square"></span></a></li>
                <li><a href="#"><span class="fab fa-twitter"></span></a></li>
                <li><a href="#"><span class="fab fa-instagram"></span></a></li>
                <li><a href="#"><span class="fab fa-pinterest-p"></span></a></li>
              </ul>
            </div>
            <div class="lower-box">
              <h5><a href="#">John Albert</a></h5>
              <div class="designation">Designer</div>
            </div>
          </div>
        </div>

        <!--Team-->
        <div class="team-block">
          <div class="inner-box">
            <div class="image-box">
              <a href="/about"><img src="/images/resource/team-4.jpg" alt=""></a>
              <ul class="social-links clearfix">
                <li><a href="#"><span class="fab fa-facebook-square"></span></a></li>
                <li><a href="#"><span class="fab fa-twitter"></span></a></li>
                <li><a href="#"><span class="fab fa-instagram"></span></a></li>
                <li><a href="#"><span class="fab fa-pinterest-p"></span></a></li>
              </ul>
            </div>
            <div class="lower-box">
              <h5><a href="#">Rose ford</a></h5>
              <div class="designation">Designer</div>
            </div>
          </div>
        </div>

        <!--Team-->
        <div class="team-block">
          <div class="inner-box">
            <div class="image-box">
              <a href="/about"><img src="/images/resource/team-5.jpg" alt=""></a>
              <ul class="social-links clearfix">
                <li><a href="#"><span class="fab fa-facebook-square"></span></a></li>
                <li><a href="#"><span class="fab fa-twitter"></span></a></li>
                <li><a href="#"><span class="fab fa-instagram"></span></a></li>
                <li><a href="#"><span class="fab fa-pinterest-p"></span></a></li>
              </ul>
            </div>
            <div class="lower-box">
              <h5><a href="#">Mike Hardson</a></h5>
              <div class="designation">Designer</div>
            </div>
          </div>
        </div>

        <!--Team-->
        <div class="team-block">
          <div class="inner-box">
            <div class="image-box">
              <a href="/about"><img src="/images/resource/team-1.jpg" alt=""></a>
              <ul class="social-links clearfix">
                <li><a href="#"><span class="fab fa-facebook-square"></span></a></li>
                <li><a href="#"><span class="fab fa-twitter"></span></a></li>
                <li><a href="#"><span class="fab fa-instagram"></span></a></li>
                <li><a href="#"><span class="fab fa-pinterest-p"></span></a></li>
              </ul>
            </div>
            <div class="lower-box">
              <h5><a href="#">Kevin martin</a></h5>
              <div class="designation">Designer</div>
            </div>
          </div>
        </div>

        <!--Team-->
        <div class="team-block">
          <div class="inner-box">
            <div class="image-box">
              <a href="/about"><img src="/images/resource/team-2.jpg" alt=""></a>
              <ul class="social-links clearfix">
                <li><a href="#"><span class="fab fa-facebook-square"></span></a></li>
                <li><a href="#"><span class="fab fa-twitter"></span></a></li>
                <li><a href="#"><span class="fab fa-instagram"></span></a></li>
                <li><a href="#"><span class="fab fa-pinterest-p"></span></a></li>
              </ul>
            </div>
            <div class="lower-box">
              <h5><a href="#">Jessica Brown</a></h5>
              <div class="designation">Designer</div>
            </div>
          </div>
        </div>

        <!--Team-->
        <div class="team-block">
          <div class="inner-box">
            <div class="image-box">
              <a href="/about"><img src="/images/resource/team-3.jpg" alt=""></a>
              <ul class="social-links clearfix">
                <li><a href="#"><span class="fab fa-facebook-square"></span></a></li>
                <li><a href="#"><span class="fab fa-twitter"></span></a></li>
                <li><a href="#"><span class="fab fa-instagram"></span></a></li>
                <li><a href="#"><span class="fab fa-pinterest-p"></span></a></li>
              </ul>
            </div>
            <div class="lower-box">
              <h5><a href="#">John Albert</a></h5>
              <div class="designation">Designer</div>
            </div>
          </div>
        </div>

        <!--Team-->
        <div class="team-block">
          <div class="inner-box">
            <div class="image-box">
              <a href="/about"><img src="/images/resource/team-4.jpg" alt=""></a>
              <ul class="social-links clearfix">
                <li><a href="#"><span class="fab fa-facebook-square"></span></a></li>
                <li><a href="#"><span class="fab fa-twitter"></span></a></li>
                <li><a href="#"><span class="fab fa-instagram"></span></a></li>
                <li><a href="#"><span class="fab fa-pinterest-p"></span></a></li>
              </ul>
            </div>
            <div class="lower-box">
              <h5><a href="#">Rose ford</a></h5>
              <div class="designation">Designer</div>
            </div>
          </div>
        </div>

        <!--Team-->
        <div class="team-block">
          <div class="inner-box">
            <div class="image-box">
              <a href="/about"><img src="/images/resource/team-5.jpg" alt=""></a>
              <ul class="social-links clearfix">
                <li><a href="#"><span class="fab fa-facebook-square"></span></a></li>
                <li><a href="#"><span class="fab fa-twitter"></span></a></li>
                <li><a href="#"><span class="fab fa-instagram"></span></a></li>
                <li><a href="#"><span class="fab fa-pinterest-p"></span></a></li>
              </ul>
            </div>
            <div class="lower-box">
              <h5><a href="#">Mike Hardson</a></h5>
              <div class="designation">Designer</div>
            </div>
          </div>
        </div>
        </carousel>
        </no-ssr>
      </div>
    </div>
  </section>
</template>

<script>
    export default {
      name: "TeamSection"
    }
</script>

<style scoped>

</style>
