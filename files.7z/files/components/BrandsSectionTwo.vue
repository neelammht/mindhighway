<template>
  <section class="sponsors-section-two">
    <div class="auto-container">
      <!--Sponsors Carousel-->
      <div class="row clearfix">
        <div class="title-col col-xl-5 col-lg-12 col-md-12">
          <div class="sec-title wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
            <h2>Some of the clients we have worked with <span class="dot">.</span></h2>
          </div>
        </div>

        <div class="logo-col col-xl-7 col-lg-12 col-md-12">
          <div class="row clearfix">
            <div class="logo-block col-xl-4 col-lg-3 col-md-4 col-sm-6 col-xs-12">
              <div class="image-box"><a href="#"><img src="/images/clients/2.png" alt=""></a></div>
            </div>
            <div class="logo-block col-xl-4 col-lg-3 col-md-4 col-sm-6 col-xs-12">
              <div class="image-box"><a href="#"><img src="/images/clients/2.png" alt=""></a></div>
            </div>
            <div class="logo-block col-xl-4 col-lg-3 col-md-4 col-sm-6 col-xs-12">
              <div class="image-box"><a href="#"><img src="/images/clients/2.png" alt=""></a></div>
            </div>
            <div class="logo-block col-xl-4 col-lg-3 col-md-4 col-sm-6 col-xs-12">
              <div class="image-box"><a href="#"><img src="/images/clients/2.png" alt=""></a></div>
            </div>
            <div class="logo-block col-xl-4 col-lg-3 col-md-4 col-sm-6 col-xs-12">
              <div class="image-box"><a href="#"><img src="/images/clients/2.png" alt=""></a></div>
            </div>
          </div>
        </div>
      </div>

    </div>
  </section>
</template>

<script>
    export default {
        name: "BrandsSectionTwo"
    }
</script>

<style scoped>

</style>
