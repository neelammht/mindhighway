<template>
  <section class="services-section-three">
    <div class="auto-container">
      <div class="sec-title centered">
        <h2>What we’re offering <span class="dot">.</span></h2>
      </div>
      <div class="services">
        <div class="row clearfix">
          <!--Service Block-->
          <div class="service-block-two col-xl-3 col-lg-6 col-md-6 col-sm-12">
            <div class="inner-box wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
              <div class="bottom-curve"></div>
              <div class="icon-box"><span class="flaticon-vector"></span></div>
              <h5><a href="#">Modern <br>Designing</a></h5>
              <div class="text">Lorem ipsum is are many variations of pass of majority.</div>
              <div class="link-box"><a href="#"><span class="fa fa-angle-right"></span></a></div>
            </div>
          </div>

          <!--Service Block-->
          <div class="service-block-two col-xl-3 col-lg-6 col-md-6 col-sm-12">
            <div class="inner-box wow fadeInUp" data-wow-delay="300ms" data-wow-duration="1500ms">
              <div class="bottom-curve"></div>
              <div class="icon-box"><span class="flaticon-digital"></span></div>
              <h5><a href="#">MARKETING <br>STRATEGY</a></h5>
              <div class="text">Lorem ipsum is are many variations of pass of majority.</div>
              <div class="link-box"><a href="#"><span class="fa fa-angle-right"></span></a></div>
            </div>
          </div>

          <!--Service Block-->
          <div class="service-block-two col-xl-3 col-lg-6 col-md-6 col-sm-12">
            <div class="inner-box wow fadeInUp" data-wow-delay="600ms" data-wow-duration="1500ms">
              <div class="bottom-curve"></div>
              <div class="icon-box"><span class="flaticon-instant-camera"></span></div>
              <h5><a href="#">Digital <br>Products</a></h5>
              <div class="text">Lorem ipsum is are many variations of pass of majority.</div>
              <div class="link-box"><a href="#"><span class="fa fa-angle-right"></span></a></div>
            </div>
          </div>

          <!--Service Block-->
          <div class="service-block-two col-xl-3 col-lg-6 col-md-6 col-sm-12">
            <div class="inner-box wow fadeInUp" data-wow-delay="900ms" data-wow-duration="1500ms">
              <div class="bottom-curve"></div>
              <div class="icon-box"><span class="flaticon-monitor"></span></div>
              <h5><a href="#">Website <br>Development</a></h5>
              <div class="text">Lorem ipsum is are many variations of pass of majority.</div>
              <div class="link-box"><a href="#"><span class="fa fa-angle-right"></span></a></div>
            </div>
          </div>

        </div>
      </div>
    </div>
  </section>
</template>

<script>
    export default {
        name: "ServicesThree"
    }
</script>

<style scoped>

</style>
