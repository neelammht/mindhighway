<template>
  <section class="news-section">
    <div class="auto-container">

      <div class="row clearfix">
        <!--News Block-->
        <div class="news-block col-lg-4 col-md-6 col-sm-12 wow fadeInUp animated" data-wow-delay="0ms" data-wow-duration="1500ms" style="visibility: visible; animation-duration: 1500ms; animation-delay: 0ms; animation-name: fadeInUp;">
          <div class="inner-box">
            <div class="image-box">
              <nuxt-link to="/blog-single"><img src="/images/resource/news-1.jpg" alt=""></nuxt-link>
            </div>
            <div class="lower-box">
              <div class="post-meta">
                <ul class="clearfix">
                  <li><span class="far fa-clock"></span> 20 Mar</li>
                  <li><span class="far fa-user-circle"></span> Admin</li>
                  <li><span class="far fa-comments"></span> 2 Comments</li>
                </ul>
              </div>
              <h5><nuxt-link to="/blog-single">basic rules of running web agency business</nuxt-link></h5>
              <div class="text">Lorem ipsum is simply free text used by copytyping refreshing.</div>
              <div class="link-box"><nuxt-link class="theme-btn" to="/blog-single"><span class="flaticon-next-1"></span></nuxt-link></div>
            </div>
          </div>
        </div>
        <!--News Block-->
        <div class="news-block col-lg-4 col-md-6 col-sm-12 wow fadeInUp animated" data-wow-delay="300ms" data-wow-duration="1500ms" style="visibility: visible; animation-duration: 1500ms; animation-delay: 300ms; animation-name: fadeInUp;">
          <div class="inner-box">
            <div class="image-box">
              <nuxt-link to="/blog-single"><img src="/images/resource/news-2.jpg" alt=""></nuxt-link>
            </div>
            <div class="lower-box">
              <div class="post-meta">
                <ul class="clearfix">
                  <li><span class="far fa-clock"></span> 20 Mar</li>
                  <li><span class="far fa-user-circle"></span> Admin</li>
                  <li><span class="far fa-comments"></span> 2 Comments</li>
                </ul>
              </div>
              <h5><nuxt-link to="/blog-single">Delivering the best digital marketing</nuxt-link></h5>
              <div class="text">Lorem ipsum is simply free text used by copytyping refreshing.</div>
              <div class="link-box"><nuxt-link class="theme-btn" to="/blog-single"><span class="flaticon-next-1"></span></nuxt-link></div>
            </div>
          </div>
        </div>
        <!--News Block-->
        <div class="news-block col-lg-4 col-md-6 col-sm-12 wow fadeInUp animated" data-wow-delay="600ms" data-wow-duration="1500ms" style="visibility: visible; animation-duration: 1500ms; animation-delay: 600ms; animation-name: fadeInUp;">
          <div class="inner-box">
            <div class="image-box">
              <nuxt-link to="/blog-single"><img src="/images/resource/news-3.jpg" alt=""></nuxt-link>
            </div>
            <div class="lower-box">
              <div class="post-meta">
                <ul class="clearfix">
                  <li><span class="far fa-clock"></span> 20 Mar</li>
                  <li><span class="far fa-user-circle"></span> Admin</li>
                  <li><span class="far fa-comments"></span> 2 Comments</li>
                </ul>
              </div>
              <h5><nuxt-link to="/blog-single">Introducing the latest linoor features</nuxt-link></h5>
              <div class="text">Lorem ipsum is simply free text used by copytyping refreshing.</div>
              <div class="link-box"><nuxt-link class="theme-btn" to="/blog-single"><span class="flaticon-next-1"></span></nuxt-link></div>
            </div>
          </div>
        </div>
        <!--News Block-->
        <div class="news-block col-lg-4 col-md-6 col-sm-12 wow fadeInUp animated" data-wow-delay="0ms" data-wow-duration="1500ms" style="visibility: visible; animation-duration: 1500ms; animation-delay: 0ms; animation-name: fadeInUp;">
          <div class="inner-box">
            <div class="image-box">
              <nuxt-link to="/blog-single"><img src="/images/resource/news-4.jpg" alt=""></nuxt-link>
            </div>
            <div class="lower-box">
              <div class="post-meta">
                <ul class="clearfix">
                  <li><span class="far fa-clock"></span> 20 Mar</li>
                  <li><span class="far fa-user-circle"></span> Admin</li>
                  <li><span class="far fa-comments"></span> 2 Comments</li>
                </ul>
              </div>
              <h5><nuxt-link to="/blog-single">EXPERIENCES THAT CONNECT WITH PEOPLE</nuxt-link></h5>
              <div class="text">Lorem ipsum is simply free text used by copytyping refreshing.</div>
              <div class="link-box"><nuxt-link class="theme-btn" to="/blog-single.html"><span class="flaticon-next-1"></span></nuxt-link></div>
            </div>
          </div>
        </div>
        <!--News Block-->
        <div class="news-block col-lg-4 col-md-6 col-sm-12 wow fadeInUp animated" data-wow-delay="300ms" data-wow-duration="1500ms" style="visibility: visible; animation-duration: 1500ms; animation-delay: 300ms; animation-name: fadeInUp;">
          <div class="inner-box">
            <div class="image-box">
              <nuxt-link to="/blog-single"><img src="/images/resource/news-5.jpg" alt=""></nuxt-link>
            </div>
            <div class="lower-box">
              <div class="post-meta">
                <ul class="clearfix">
                  <li><span class="far fa-clock"></span> 20 Mar</li>
                  <li><span class="far fa-user-circle"></span> Admin</li>
                  <li><span class="far fa-comments"></span> 2 Comments</li>
                </ul>
              </div>
              <h5><nuxt-link to="/blog-single">A DEEP UNDERSTANDING OF OUR AUDIENCE</nuxt-link></h5>
              <div class="text">Lorem ipsum is simply free text used by copytyping refreshing.</div>
              <div class="link-box"><nuxt-link class="theme-btn" to="/blog-single.html"><span class="flaticon-next-1"></span></nuxt-link></div>
            </div>
          </div>
        </div>
        <!--News Block-->
        <div class="news-block col-lg-4 col-md-6 col-sm-12 wow fadeInUp animated" data-wow-delay="600ms" data-wow-duration="1500ms" style="visibility: visible; animation-duration: 1500ms; animation-delay: 600ms; animation-name: fadeInUp;">
          <div class="inner-box">
            <div class="image-box">
              <nuxt-link to="/blog-single"><img src="/images/resource/news-6.jpg" alt=""></nuxt-link>
            </div>
            <div class="lower-box">
              <div class="post-meta">
                <ul class="clearfix">
                  <li><span class="far fa-clock"></span> 20 Mar</li>
                  <li><span class="far fa-user-circle"></span> Admin</li>
                  <li><span class="far fa-comments"></span> 2 Comments</li>
                </ul>
              </div>
              <h5><nuxt-link to="/blog-single">WE BUILD AND ACTIVATE BRANDS INSIGHT</nuxt-link></h5>
              <div class="text">Lorem ipsum is simply free text used by copytyping refreshing.</div>
              <div class="link-box"><nuxt-link class="theme-btn" to="/blog-single"><span class="flaticon-next-1"></span></nuxt-link></div>
            </div>
          </div>
        </div>
      </div>
      <div class="more-box">
        <nuxt-link class="theme-btn btn-style-one" to="/blog">
          <i class="btn-curve"></i>
          <span class="btn-title">Load more posts</span>
        </nuxt-link>
      </div>
    </div>
  </section>
</template>

<script>
    export default {
        name: "BlogPage"
    }
</script>

<style scoped>

</style>
