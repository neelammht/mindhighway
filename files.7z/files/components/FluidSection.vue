<template>
  <section class="fluid-section">
    <div class="outer-container">
      <div class="row clearfix">
        <div class="column col-lg-6 col-md-12 col-sm-12">
          <div class="inner">
            <div class="image-layer" style="background-image: url(/images/background/image-4.jpg);">
            </div>
            <div class="content-box">
              <h3>BUILD a BETTER WEBSITE ALOT QUICKER WITH linoor</h3>
              <div class="link-box">
                <nuxt-link class="theme-btn btn-style-one" to="/about">
                  <i class="btn-curve"></i>
                  <span class="btn-title">Discover More</span>
                </nuxt-link>
              </div>
            </div>
          </div>
        </div>
        <div class="column col-lg-6 col-md-12 col-sm-12">
          <div class="inner">
            <div class="image-layer" style="background-image: url(/images/background/image-5.jpg);">
            </div>
            <div class="content-box">
              <h3>We provide our customers with exceptional service</h3>
              <div class="link-box">
                <nuxt-link class="theme-btn btn-style-two" to="/contact">
                  <i class="btn-curve"></i>
                  <span class="btn-title">Discover More</span>
                </nuxt-link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
    export default {
        name: "FluidSection"
    }
</script>

<style scoped>

</style>
