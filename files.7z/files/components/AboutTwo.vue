<template>
  <section class="about-section-two">
    <div class="auto-container">
      <div class="row clearfix">
        <!--Left Column-->
        <div class="left-col col-lg-6 col-md-12 col-sm-12">
          <div class="inner">
            <div class="sec-title">
              <h2>We are standout <br>experts in business <span class="dot">.</span></h2>
              <div class="lower-text">We believe that success is achieved through a highly
                collaborative interaction, so that we can work together to identify and evaluate
                opportunities beyond your current operations. </div>
            </div>
            <div class="counter">
              <div class="row clearfix">
                <div class="counter-block col-lg-6 col-md-6 col-sm-12">
                  <div class="inner-box">
                    <div class="graph-outer">
                      <div style="display:inline;width:140px;height:140px;"><canvas width="175" height="175" style="width: 140px; height: 140px;"></canvas><input type="text" class="dial" data-fgcolor="#ffaa17" data-bgcolor="none" data-width="140" data-height="140" data-linecap="normal" value="90" data-thickness="0.050" style="display: none; width: 0px; visibility: hidden;" readonly="readonly"></div>
                      <div class="inner-text count-box counted"><span class="count-text" data-stop="90" data-speed="2000">90</span><span class="sign">%</span></div>
                    </div>
                    <h4>Quality <br>Services</h4>
                  </div>
                </div>
                <div class="counter-block col-lg-6 col-md-6 col-sm-12">
                  <div class="inner-box">
                    <div class="graph-outer">
                      <div style="display:inline;width:140px;height:140px;"><canvas width="175" height="175" style="width: 140px; height: 140px;"></canvas><input type="text" class="dial" data-fgcolor="#ffaa17" data-bgcolor="none" data-width="140" data-height="140" data-linecap="normal" value="50" data-thickness="0.050" style="display: none; width: 0px; visibility: hidden;" readonly="readonly"></div>
                      <div class="inner-text count-box counted"><span class="count-text" data-stop="50" data-speed="2000">50</span><span class="sign">%</span></div>
                    </div>
                    <h4>Skilled <br>Employee</h4>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!--Right Column-->
        <div class="right-col col-lg-6 col-md-12 col-sm-12">
          <div class="inner">
            <div class="image-box wow fadeInRight" data-wow-delay="0ms" data-wow-duration="1500ms">
              <div class="image"><img src="/images/resource/featured-image-15.jpg" alt=""></div>
              <div class="since"><span class="txt">Since <br>2008</span></div>
            </div>
          </div>
        </div>

      </div>
    </div>
  </section>
</template>

<script>
    export default {
        name: "AboutTwo"
    }
</script>

<style scoped>

</style>
