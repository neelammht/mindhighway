<template>
  <section class="call-to-section-two">
    <div class="auto-container">
      <div class="inner clearfix">
        <h2>We’re Ready to Bring Bigger <br>& Stronger Projects</h2>
        <div class="link-box">
          <nuxt-link class="theme-btn btn-style-one" to="/about">
            <i class="btn-curve"></i>
            <span class="btn-title">Contact with us</span>
          </nuxt-link>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
    export default {
        name: "CallToActionTwo"
    }
</script>

<style scoped>

</style>
