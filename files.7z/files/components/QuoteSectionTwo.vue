<template>
  <section class="get-quote-two">
    <div class="auto-container">
      <div class="row clearfix">
        <!--Left Column-->
        <div class="left-col col-lg-6 col-md-12 col-sm-12">
          <div class="inner">
            <div class="sec-title">
              <h2>We are always here to help you<span class="dot">.</span></h2>
            </div>
            <div class="text">There are many variatns of passages the majority have suffered alteration
              in some foor randomised words believable.</div>
            <div class="info">
              <ul>
                <li class="address">
                  <span class="icon flaticon-pin-1"></span>
                  <strong>Visit Us</strong>
                  66 Broklyn Street, New York. USA
                </li>
                <li>
                  <span class="icon flaticon-email-2"></span>
                  <strong>Email address</strong>
                  <a href="mailto:needhelp@linoor.com">needhelp@linoor.com</a>
                </li>
                <li>
                  <span class="icon flaticon-call"></span>
                  <strong>Call now</strong>
                  <a href="tel:666888000">666 888 000</a>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <!--Right Column-->
        <div class="right-col col-lg-6 col-md-12 col-sm-12">
          <div class="inner">
            <div class="form-box">
              <div class="default-form">
                <form method="post" action="#" id="contact-form">
                  <div class="row clearfix">
                    <div class="form-group col-lg-6 col-md-6 col-sm-12">
                      <div class="field-inner">
                        <input type="text" name="username" value="" placeholder="Your Name"
                               required="">
                      </div>
                    </div>
                    <div class="form-group col-lg-6 col-md-6 col-sm-12">
                      <div class="field-inner">
                        <input type="email" name="email" value=""
                               placeholder="Email Address" required="">
                      </div>
                    </div>
                    <div class="form-group col-lg-6 col-md-6 col-sm-12">
                      <div class="field-inner">
                        <input type="text" name="phone" value="" placeholder="Phone Number"
                               required="">
                      </div>
                    </div>
                    <div class="form-group col-lg-6 col-md-6 col-sm-12">
                      <div class="field-inner">
                        <input type="text" name="subject" value="" placeholder="Subject"
                               required="">
                      </div>
                    </div>
                    <div class="form-group col-lg-12 col-md-12 col-sm-12">
                      <div class="field-inner">
                                                    <textarea name="message" placeholder="Write Message"
                                                              required=""></textarea>
                      </div>
                    </div>
                    <div class="form-group col-lg-12 col-md-12 col-sm-12">
                      <button class="theme-btn btn-style-one">
                        <i class="btn-curve"></i>
                        <span class="btn-title">Send message</span>
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  </section>
</template>

<script>
    export default {
        name: "QuoteSectionTwo"
    }
</script>

<style scoped>

</style>
