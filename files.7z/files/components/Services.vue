<template>
  <section class="services-section">
    <div class="auto-container">
      <div class="row clearfix">
        <!--Title Block-->
        <div class="title-block col-xl-6 col-lg-12 col-md-12 col-sm-12">
          <div class="inner">
            <div class="sec-title">
              <h2>We Shape the Perfect <br>Solutions<span class="dot">.</span></h2>
              <div class="lower-text">We are committed to providing our customers with exceptional
                service while offering our employees the best training.</div>
            </div>
          </div>
        </div>
        <!--Service Block-->
        <div class="service-block col-xl-3 col-lg-6 col-md-6 col-sm-12 wow fadeInLeft" data-wow-delay="0ms"
             data-wow-duration="1500ms">
          <div class="inner-box">
            <div class="bottom-curve"></div>
            <div class="icon-box"><span class="flaticon-responsive"></span></div>
            <h6><nuxt-link to="/web-development">Website <br>Development</nuxt-link></h6>
          </div>
        </div>
        <!--Service Block-->
        <div class="service-block col-xl-3 col-lg-6 col-md-6 col-sm-12 wow fadeInLeft"
             data-wow-delay="300ms" data-wow-duration="1500ms">
          <div class="inner-box">
            <div class="bottom-curve"></div>
            <div class="icon-box"><span class="flaticon-computer"></span></div>
            <h6><nuxt-link to="/graphic-designing">graphic <br>designing</nuxt-link></h6>
          </div>
        </div>
        <!--Service Block-->
        <div class="service-block col-xl-3 col-lg-6 col-md-6 col-sm-12 wow fadeInLeft" data-wow-delay="0ms"
             data-wow-duration="1500ms">
          <div class="inner-box">
            <div class="bottom-curve"></div>
            <div class="icon-box"><span class="flaticon-digital-marketing"></span></div>
            <h6><nuxt-link to="/digital-marketing">digital <br>marketing</nuxt-link></h6>
          </div>
        </div>
        <!--Service Block-->
        <div class="service-block col-xl-3 col-lg-6 col-md-6 col-sm-12 wow fadeInLeft"
             data-wow-delay="300ms" data-wow-duration="1500ms">
          <div class="inner-box">
            <div class="bottom-curve"></div>
            <div class="icon-box"><span class="flaticon-development"></span></div>
            <h6><nuxt-link to="/seo">seo & content <br>writing</nuxt-link></h6>
          </div>
        </div>
        <!--Service Block-->
        <div class="service-block col-xl-3 col-lg-6 col-md-6 col-sm-12 wow fadeInLeft"
             data-wow-delay="600ms" data-wow-duration="1500ms">
          <div class="inner-box">
            <div class="bottom-curve"></div>
            <div class="icon-box"><span class="flaticon-app-development"></span></div>
            <h6><nuxt-link to="/app-development">App <br>Development</nuxt-link></h6>
          </div>
        </div>
        <!--Service Block-->
        <div class="service-block col-xl-3 col-lg-6 col-md-6 col-sm-12 wow fadeInLeft"
             data-wow-delay="900ms" data-wow-duration="1500ms">
          <div class="inner-box">
            <div class="bottom-curve"></div>
            <div class="icon-box"><span class="flaticon-ui"></span></div>
            <h6><nuxt-link to="/ui-designing">Ui/UX <br>designing</nuxt-link></h6>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
    export default {
        name: "Services"
    }
</script>

<style scoped>

</style>
