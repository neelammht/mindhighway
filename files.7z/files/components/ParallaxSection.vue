<template>
  <section class="parallax-section">
    <div class="image-layer" style="background-image: url(/images/background/image-2.jpg);"></div>
    <div class="auto-container">
      <div class="content-box">
        <div class="icon-box"><span class="flaticon-app-development"></span></div>
        <h2>Great things in business are never done by one person. <span>They’re done by a team of
                            people.</span></h2>
      </div>
    </div>
  </section>
</template>

<script>
    export default {
        name: "ParallaxSection"
    }
</script>

<style scoped>

</style>
