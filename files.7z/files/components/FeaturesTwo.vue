<template>
  <section class="features-section-two">
    <div class="auto-container">
      <div class="content-container">
        <div class="row clearfix">
          <!--Left Column-->
          <div class="left-col col-lg-5 col-md-12 col-sm-12">
            <div class="inner">
              <div class="sec-title">
                <h2>Linoor all core features <span class="dot">.</span></h2>
              </div>
              <div class="features">
                <div class="feature">
                  <div class="count"><span>01</span></div>
                  <h5>Professional Staff</h5>
                  <div class="sub-text">There are many variations of passages of lorem ipsum
                    majority have suffered.</div>
                </div>
                <div class="feature">
                  <div class="count"><span>02</span></div>
                  <h5>100% Satisfaction</h5>
                  <div class="sub-text">There are many variations of passages of lorem ipsum
                    majority have suffered.</div>
                </div>
                <div class="feature">
                  <div class="count"><span>03</span></div>
                  <h5>Quality designing</h5>
                  <div class="sub-text">There are many variations of passages of lorem ipsum
                    majority have suffered.</div>
                </div>
              </div>
            </div>
          </div>
          <!--Right Column-->
          <div class="right-col col-lg-7 col-md-12 col-sm-12">
            <div class="inner">
              <div class="image-box wow fadeInRight" data-wow-delay="0ms" data-wow-duration="1500ms">
                <img src="/images/resource/featured-image-13.jpg" alt="">
                <div class="cap-box">
                  <div class="cap-inner">
                    <h5>Total design freedom for everyone</h5>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
    export default {
        name: "FeaturesTwo"
    }
</script>

<style scoped>

</style>
