<template>
  <section class="gallery-section-two alternate">
    <div class="auto-container">
      <div class="sec-title centered">
        <h2>Our work showcase <span class="dot">.</span></h2>
      </div>
    </div>
    <!--Porfolio Tabs-->
    <div class="project-tab">
      <!--Tabs Content-->
      <div class="p-tabs-content">
        <div class="auto-container">
        <!--Portfolio Tab / Active Tab-->
        <div class="p-tab active-tab" id="p-tab-1">
          <div class="project-carousel-two">

            <carousel :dots="false" :margin="30" :autoplay="true" :responsive="{0: {items: 1},640: {items: 2},992: {items: 3},1200: {items: 3}}">

              <!-- Gallery Item -->
              <div class="gallery-item">
                <div class="inner-box">
                  <figure class="image"><img src="/images/gallery/8.jpg" alt=""></figure>
                  <a href="/images/gallery/8.jpg" class="lightbox-image overlay-box"
                     data-fancybox="gallery"></a>
                  <div class="cap-box">
                    <div class="cap-inner">
                      <div class="cat"><span>Graphic</span></div>
                      <div class="title">
                        <h5><a href="/portfolio-single">Fimlor Experience</a></h5>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Gallery Item -->
              <div class="gallery-item">
                <div class="inner-box">
                  <figure class="image"><img src="/images/gallery/9.jpg" alt=""></figure>
                  <a href="/images/gallery/9.jpg" class="lightbox-image overlay-box"
                     data-fancybox="gallery"></a>
                  <div class="cap-box">
                    <div class="cap-inner">
                      <div class="cat"><span>Graphic</span></div>
                      <div class="title">
                        <h5><a href="/portfolio-single">Fimlor Experience</a></h5>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Gallery Item -->
              <div class="gallery-item">
                <div class="inner-box">
                  <figure class="image"><img src="/images/gallery/10.jpg" alt=""></figure>
                  <a href="/images/gallery/10.jpg" class="lightbox-image overlay-box"
                     data-fancybox="gallery"></a>
                  <div class="cap-box">
                    <div class="cap-inner">
                      <div class="cat"><span>Graphic</span></div>
                      <div class="title">
                        <h5><a href="/portfolio-single">Fimlor Experience</a></h5>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Gallery Item -->
              <div class="gallery-item">
                <div class="inner-box">
                  <figure class="image"><img src="/images/gallery/7.jpg" alt=""></figure>
                  <a href="/images/gallery/7.jpg" class="lightbox-image overlay-box"
                     data-fancybox="gallery"></a>
                  <div class="cap-box">
                    <div class="cap-inner">
                      <div class="cat"><span>Graphic</span></div>
                      <div class="title">
                        <h5><a href="/portfolio-single">Fimlor Experience</a></h5>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Gallery Item -->
              <div class="gallery-item">
                <div class="inner-box">
                  <figure class="image"><img src="/images/gallery/8.jpg" alt=""></figure>
                  <a href="/images/gallery/8.jpg" class="lightbox-image overlay-box"
                     data-fancybox="gallery"></a>
                  <div class="cap-box">
                    <div class="cap-inner">
                      <div class="cat"><span>Graphic</span></div>
                      <div class="title">
                        <h5><a href="/portfolio-single">Fimlor Experience</a></h5>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Gallery Item -->
              <div class="gallery-item">
                <div class="inner-box">
                  <figure class="image"><img src="/images/gallery/9.jpg" alt=""></figure>
                  <a href="/images/gallery/9.jpg" class="lightbox-image overlay-box"
                     data-fancybox="gallery"></a>
                  <div class="cap-box">
                    <div class="cap-inner">
                      <div class="cat"><span>Graphic</span></div>
                      <div class="title">
                        <h5><a href="/portfolio-single">Fimlor Experience</a></h5>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Gallery Item -->
              <div class="gallery-item">
                <div class="inner-box">
                  <figure class="image"><img src="/images/gallery/10.jpg" alt=""></figure>
                  <a href="/images/gallery/10.jpg" class="lightbox-image overlay-box"
                     data-fancybox="gallery"></a>
                  <div class="cap-box">
                    <div class="cap-inner">
                      <div class="cat"><span>Graphic</span></div>
                      <div class="title">
                        <h5><a href="/portfolio-single">Fimlor Experience</a></h5>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Gallery Item -->
              <div class="gallery-item">
                <div class="inner-box">
                  <figure class="image"><img src="/images/gallery/7.jpg" alt=""></figure>
                  <a href="/images/gallery/7.jpg" class="lightbox-image overlay-box"
                     data-fancybox="gallery"></a>
                  <div class="cap-box">
                    <div class="cap-inner">
                      <div class="cat"><span>Graphic</span></div>
                      <div class="title">
                        <h5><a href="/portfolio-single">Fimlor Experience</a></h5>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Gallery Item -->
              <div class="gallery-item">
                <div class="inner-box">
                  <figure class="image"><img src="/images/gallery/8.jpg" alt=""></figure>
                  <a href="/images/gallery/8.jpg" class="lightbox-image overlay-box"
                     data-fancybox="gallery"></a>
                  <div class="cap-box">
                    <div class="cap-inner">
                      <div class="cat"><span>Graphic</span></div>
                      <div class="title">
                        <h5><a href="/portfolio-single">Fimlor Experience</a></h5>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Gallery Item -->
              <div class="gallery-item">
                <div class="inner-box">
                  <figure class="image"><img src="/images/gallery/9.jpg" alt=""></figure>
                  <a href="/images/gallery/9.jpg" class="lightbox-image overlay-box"
                     data-fancybox="gallery"></a>
                  <div class="cap-box">
                    <div class="cap-inner">
                      <div class="cat"><span>Graphic</span></div>
                      <div class="title">
                        <h5><a href="/portfolio-single">Fimlor Experience</a></h5>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Gallery Item -->
              <div class="gallery-item">
                <div class="inner-box">
                  <figure class="image"><img src="/images/gallery/10.jpg" alt=""></figure>
                  <a href="/images/gallery/10.jpg" class="lightbox-image overlay-box"
                     data-fancybox="gallery"></a>
                  <div class="cap-box">
                    <div class="cap-inner">
                      <div class="cat"><span>Graphic</span></div>
                      <div class="title">
                        <h5><a href="/portfolio-single">Fimlor Experience</a></h5>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </carousel>
          </div>
        </div>

      </div>
      </div>
    </div>
  </section>
</template>

<script>
  export default {
    name: "GalleryCarouselTwo",
    mounted () {
      new GLightbox({
        selector: '.lightbox-image',
        touchNavigation: true,
        loop: true,
        autoplayVideos: true
      });
    },
  }
</script>

<style scoped>

</style>
