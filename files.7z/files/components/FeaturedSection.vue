<template>
  <section class="featured-section">
    <div class="auto-container">
      <div class="row clearfix">
        <!--Left Column-->
        <div class="left-col col-lg-6 col-md-12 col-sm-12">
          <div class="inner wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
            <div class="image-box"><img src="/images/resource/featured-image-7.jpg" alt=""></div>
          </div>
        </div>
        <!--Right Column-->
        <div class="right-col col-lg-6 col-md-12 col-sm-12">
          <div class="inner">
            <div class="sec-title">
              <h2>MAKE WEBSITES WITHOUT TOUCHING the CODing <span class="dot">.</span></h2>
              <div class="lower-text">We are committed to providing our customers with exceptional
                service while offering our employees the best training. There are many variations of
                passages of lorem ipsum is simply free text available in the market, but the
                majority have suffered time.</div>
            </div>
            <div class="features">
              <div class="row clearfix">
                <div class="feature col-md-6 col-sm-12">
                  <div class="inner-box">
                    <h6>Free Consultation</h6>
                    <div class="text">Lorem ipsum is not dolor sit amet, consectetur notted.
                    </div>
                  </div>
                </div>
                <div class="feature col-md-6 col-sm-12">
                  <div class="inner-box">
                    <h6>Best team members</h6>
                    <div class="text">Lorem ipsum is not dolor sit amet, consectetur notted.
                    </div>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
    export default {
        name: "FeaturedSection"
    }
</script>

<style scoped>

</style>
